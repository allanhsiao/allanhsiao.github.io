module Elevation

import ArchGDAL as AG
import Geo as G
using ..Coast, Rasters, Rasters.Lookups

delta = G.read_shp("data/delta/deltadtm_tiles.gpkg")
tiles = AG.getgeom.(delta)
lngs = AG.getfield.(delta, :longitude)
lats = AG.getfield.(delta, :latitude)

folders = map(x -> x[1:end-4], AG.getfield.(delta, :zipfile))
files = AG.getfield.(delta, :tile)
tilepaths = "data/delta/" .* folders .* "/" .* files
maskpaths = "data/delta/masks/" .* files

function read(cen; mask=false)
    intile = AG.within.(Ref(cen), tiles)
    if !any(intile) 
        inland = Coast.inland(cen)
        block  = ones(3600,3600)
        mask  && return inland ? 0*block  : 1*block
        !mask && return inland ? 30*block : -9999*block
    end
    idx = findfirst(intile)    
    data = G.read_tif(mask ? maskpaths[idx] : tilepaths[idx])
    return project(data, idx)
end

function project(tile, idx)
    width = size(tile,2)
    width == 3600 && return tile
    width == 1800 && return repeat(tile, inner=(1, 2))
    width == 1200 && return repeat(tile, inner=(1, 3))    
    lat, lng = lats[idx], lngs[idx]
    xs = G.arcrange(lng, lng+1, 3600/width)
    ys = G.arcrange(lat, lat+1, 1)
    dim = X(Projected(xs; sampling=Intervals(), crs=EPSG(9518))),
          Y(Projected(ys; sampling=Intervals(), crs=EPSG(9518)))    
    raster = Raster(reverse(tile''', dims=2), dim)
    raster_ = resample(raster; size=(3600,3600), crs=EPSG(4326))
    return reverse(Matrix(raster_)', dims=1)
end
fuse(mat) = vcat([hcat(row...) for row in eachrow(mat)]...)

function raster(box; mask=false)
    tilebox = G.Box( floor(box.lngmin), ceil(box.lngmax), 
                     floor(box.latmin), ceil(box.latmax) )
    lats = G.arcrange(tilebox.latmin, tilebox.latmax, 3600)
    lngs = G.arcrange(tilebox.lngmin, tilebox.lngmax, 3600)
    cens = [(lng, lat) for lat in reverse(lats), lng in lngs]
    cens = AG.createpoint.(cens)
    tiles = fuse(read.(cens; mask=mask))
    crop = G.crop(tiles, tilebox, box)
    @assert .!all(crop .== 0)
    return crop
end
mask(box) = raster(box; mask=true)

indelta(poly) = any(AG.intersects.(Ref(poly), tiles))

end
module Sea

import ArchGDAL as AG
import Geo as G
using ..City, ..Coast, ..Elevation

levels = 0:0.1:5  # meters SLR
safe = Dict(levels .=> false)

function inundation(elevation, ocean, lake, river, level; start = ocean)
    ocean_ = Bool.(ocean)
    queue = findall(start)
    while !isempty(queue)
        current = pop!(queue)
        (cx, cy) = Tuple(current)
        for dx in -1:1, dy in -1:1
            if dx == 0 && dy == 0
                continue
            end
            nx, ny = cx + dx, cy + dy
            if 1 <= nx <= size(ocean,1) && 1 <= ny <= size(ocean,2)
                if !ocean_[nx, ny] && elevation[nx, ny] <= level
                    ocean_[nx, ny] = true
                    push!(queue, CartesianIndex(nx, ny))
                end
            end
        end
    end
    return ocean_ .|| lake .|| river
end

function allneighbors(mat)
    pad = trues(size(mat) .+ 2)
    pad[2:end-1, 2:end-1] = mat
    shift(i,j) = pad[(2:end-1) .+ i, (2:end-1) .+ j]
    return mat .&& shift(-1, 0) .&& shift( 1, 0) .&&
           shift( 0,-1) .&& shift( 0, 1) .&& shift(-1,-1) .&&
           shift(-1, 1) .&& shift( 1,-1) .&& shift( 1, 1)
end

function rasters(poly, box)
    city = City.raster(poly, box)
    elevation = Elevation.raster(box)
    water = Elevation.mask(box)
    ocean = water .== 1
    lake  = water .== 2 
    river = water .== 3
    @assert all(elevation[water .!= 0] .== -9999)
    @assert all(water[elevation .== -9999] .!= 0)
    
    maxlevel = levels[end]
    maxind = inundation(elevation, ocean, lake, river, maxlevel)
    !any(maxind[city]) && return safe

    start = ocean .&& .!allneighbors(ocean)
    raster(level) = inundation(elevation, ocean, lake, river, level; start=start)
    return Dict(levels .=> raster.(levels))
end

end
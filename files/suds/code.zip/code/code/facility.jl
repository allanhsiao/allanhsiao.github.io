module Facility

import ArchGDAL as AG
import Geo as G 

types = [ "school", "college", "university", "kindergarten",
          "hospital", "clinic", "doctors", "dentist", "pharmacy" ]
continents = [ "africa", "asia", "australia-oceania", "europe",
          "central-america", "north-america", "south-america" ]

read_osm(c, t) = G.read_pbf("data/osm/$(c)-$(t).osm.pbf")

function make_facilities(continent, type)
    data = read_osm(continent, type)
    points = AG.getgeom.(AG.getlayer(data, 0))
    polys = AG.getgeom.(AG.getlayer(data, 3))
    points_inpoly = AG.intersection(mpoint(points), mpoly(polys))
    points_inpoly = components(points_inpoly)
    points = points[points .∉ Ref(points_inpoly)]
    polys = AG.centroid.(polys)
    return vcat(points, polys)
end
function mpoint(points)
    m = AG.createmultipoint()
    for point in points
        AG.addgeom!(m, point)
    end
    return m 
end 
function mpoly(polys)
    m = AG.createmultipolygon()
    for poly in polys, i in 1:AG.ngeom(poly)
        AG.addgeom!(m, AG.getgeom(poly, i-1))
    end
    return m 
end
components(geom) = [AG.getgeom(geom, i-1) for i in 1:AG.ngeom(geom)]
make_facilities(type) = vcat(make_facilities.(continents, type)...)
facilities = Dict(types .=> make_facilities.(types))

raster(box, type) = G.rasterize(facilities[type], box; total=true)
rasters(box) = Dict(types .=> raster.(Ref(box), types))

end
module Road 

import ArchGDAL as AG
import Geo as G

types = ["highway", "primary", "secondary", "tertiary"]
regions = 1:7

read_grip(r) = G.read_shp("data/grip/GRIP4_Region$(r)_vector_shp/GRIP4_region$(r).shp")
grip = vcat(read_grip.(regions)...)
griptype = AG.getfield.(grip, :GP_RTP)

function make_roads(type)
    t = findfirst(types .== type)
    return AG.getgeom.(grip[griptype .== t])
end
roads = Dict(types .=> make_roads.(types))

function kilometer(poly, type)
    lines = roads[type]
    polylines = lines[AG.intersects.(lines, Ref(poly))]
    polylines = AG.intersection.(polylines, Ref(poly))
    G.meters!.(polylines, Ref(poly))
    lengths = AG.geomlength.(polylines) / 1000
    return sum(lengths)
end
kilometers(poly) = Dict(types .=> kilometer.(Ref(poly), types))

raster(box, type) = G.rasterize(roads[type], box)
rasters(box) = Dict(types .=> raster.(Ref(box), types))

end
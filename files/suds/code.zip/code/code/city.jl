module City

import ArchGDAL as AG
import Geo as G 
using DataFrames, StatsBase

ghs = begin
    shp = G.read_shp("data/ghs/GHS_UCDB_THEME_SOCIOECONOMIC_GLOBE_R2024A.gpkg")
    pop = AG.getfield.(shp, :GC_POP_TOT_2025)
    shp[sortperm(pop, rev=true)]
end

function reproject!(poly)
    target = AG.importEPSG(4326; order=:trad)
    source = AG.importPROJ4("+proj=moll +lon_0=0 +x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs")
    AG.createcoordtrans(source, target) do transform
        AG.transform!(poly, transform)
    end
end

polys = AG.getgeom.(ghs); reproject!.(polys)
names = AG.getfield.(ghs, :GC_UCN_MAI_2025)
areas = AG.getfield.(ghs, :GC_UCA_KM2_2025)

gs = eachindex(ghs)
ids = AG.getfield.(ghs, :ID_UC_G0)
countries = AG.getfield.(ghs, :GC_CNT_GAD_2025)
pops = AG.getfield.(ghs, :GC_POP_TOT_2025)
gdps = AG.getfield.(ghs, :SC_SEC_GDP_2020)
gdp_qs = begin 
    cuts = percentile.(Ref(gdps), [25,50,75])
    qs = map(g -> sum(g .> cuts) + 1, gdps)
    "q" .* string.(qs)
end

data = DataFrame( g = gs, ghs = ids, city = names,
                  country = countries, area = areas,
                  pop = pops, gdp = gdp_qs )

raster(poly, box) = G.rasterize(poly, box)

end 
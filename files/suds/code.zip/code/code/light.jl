module Light

import Geo as G 

viirs = G.read_tif("data/viirs/VNL_npp_2023_global_vcmslcfg_v2_c202402081600.average_masked.dat.tif")[1:end-1, 1:end-1]
viirsbox = G.Box(-180, 180, -65, 75)
viirsarc = 15

function raster(box)
    crop = G.crop(viirs, viirsbox, box; arcsec=viirsarc)
    sharp = G.sharpen(crop, viirsarc)
    return sharp
end

end
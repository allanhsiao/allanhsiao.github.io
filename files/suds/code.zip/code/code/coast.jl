module Coast

import ArchGDAL as AG
import Geo as G

far = 500  # kilometers

gshhg = AG.getgeom.(G.read_shp("data/gshhg/GSHHS_c_L1.shp"))
null = AG.createlinestring()

lands(geom) = gshhg[AG.intersects.(Ref(geom), gshhg)]

function closest(geom)
    coasts = AG.boundary.(lands(geom))
    isempty(coasts) && return null
    dist, close = findmin(AG.distance.(Ref(geom), coasts))
    dist == 0 && return null
    coast = coasts[close]
    geom_ = AG.buffer(geom, dist + 0.1)
    coast_ = AG.intersection(geom_, coast)
    return coast_
end

inland(geom) = !isempty(lands(geom))

function farinland(geom)
    geom_ = AG.boundary(geom)
    coast_ = closest(geom)
    coast_ == null && return false
    G.meters!(geom_, geom)
    G.meters!(coast_, geom)
    dist_km = AG.distance(geom_, coast_) / 1000
    return dist_km >= far
end

end
module Geo

import ArchGDAL as AG
using CSV, DataFrames, Plots, StatsBase
using Rasters
using Rasters.Lookups

function arcrange(min, max, arcsec) 
    s = arcsec / 3600
    return min + s/2 : s : max
end

struct Box
    lngmin; lngmax; latmin; latmax
end
function Box(geom; buffer=60, arcsec=60)
    b = buffer / 3600
    a = arcsec / 3600
    geom_ = b > 0 ? AG.buffer(geom, b) : geom
    box = AG.envelope(geom_)
    lngmin = floor(box.MinX / a) * a
    lngmax = ceil(box.MaxX / a) * a
    latmin = floor(box.MinY / a) * a
    latmax = ceil(box.MaxY / a) * a
    return Box(lngmin, lngmax, latmin, latmax)
end
MapBox(poly) = Box(poly; buffer=900)

function coarsen(x, c)
    x̃ = reshape( x, c, fld(size(x,1),c), 
                    c, fld(size(x,2),c) )
    x̃ = mean(x̃, dims=(1,3))
    x̃ = dropdims(x̃, dims=(1,3))
    return x̃    
end

function crop(raster, rasterbox, cropbox; arcsec=1)
    rasterlngs = arcrange(rasterbox.lngmin, rasterbox.lngmax, arcsec)
    rasterlats = arcrange(rasterbox.latmin, rasterbox.latmax, arcsec)
    croplngs = arcrange(cropbox.lngmin, cropbox.lngmax, arcsec)
    croplats = arcrange(cropbox.latmin, cropbox.latmax, arcsec)
    lng1 = lngrangeidx(rasterlngs, croplngs[1])
    lng2 = lngrangeidx(rasterlngs, croplngs[end])
    lat1 = latrangeidx(rasterlats, croplats[end])
    lat2 = latrangeidx(rasterlats, croplats[1])
    return raster[lat1:lat2, lng1:lng2]
end

lng(point) = AG.getx(point, 0)
lat(point) = AG.gety(point, 0)
lngrangeidx(range, val) = round(Int, (val - range[1]) / step(range)) + 1
latrangeidx(range, val) = length(range) + 1 - lngrangeidx(range, val)

function map(mat)
    color(i) = i == 0 ? colorant"black" :
            i == 1 ? colorant"green" :
            i == 2 ? colorant"red" : 
            i == 3 ? colorant"blue" : ERROR
    plot(color.(mat); showaxis=false, grid=false )
end

function meters!(geom, refgeom)
    UTM = begin
        cen = AG.centroid(refgeom)
        zone = floor(Int, (lng(cen) + 180) / 6) + 1
        (lat(cen) >= 0 ? 32600 : 32700) + zone
    end    
    target = AG.importEPSG(UTM)
    source = AG.importEPSG(4326; order=:trad)
    AG.createcoordtrans(source, target) do transform
        AG.transform!(geom, transform)
    end
end

function rasterize(geom, box; arcsec=1, total=false)
    lngs = arcrange(box.lngmin, box.lngmax, arcsec)
    lats = arcrange(box.latmin, box.latmax, arcsec)
    dim = X(Projected(lngs; sampling=Intervals(), crs=EPSG(4326))),
          Y(Projected(lats; sampling=Intervals(), crs=EPSG(4326)))
    raster = zeros(total ? Int32 : Bool, dim)
    rasterize!(total ? sum : last, raster, geom; fill=1, progress=false, verbose=false)
    return reverse(Matrix(raster)', dims=1)
end

read_pbf(file) = AG.read(file)
read_shp(file) = AG.getlayer(AG.read(file), 0) |> collect
read_tif(file) = AG.read(AG.read(file), 1)'

sharpen(x, c) = repeat(x; inner = (c,c))

end
cd(@__DIR__); push!(LOAD_PATH, "code")

import ArchGDAL as AG
import Geo as G
using CSV, DataFrames, LinearAlgebra, Plots, StatsBase

include("code/city.jl")
include("code/coast.jl")
include("code/elevation.jl")
include("code/sea.jl")
include("code/facility.jl")
include("code/road.jl")
include("code/light.jl")

function make_data(g)

    poly = City.polys[g]
    name = City.names[g]
    area = City.areas[g]
    box  = G.Box(poly)

    if !Elevation.indelta(poly) || Coast.farinland(poly)

        city = City.raster(poly, box)
        seas = Sea.safe

    else 

        coastbox = G.MapBox(AG.union(poly, Coast.closest(poly)))
        city = City.raster(poly, coastbox)
        land = Elevation.mask(coastbox) .== 0

        city[.!land] .= false
        G.map(land + city)
        savefig("suds/fig/map$(g)_land.png")

        seas = Sea.rasters(poly, coastbox)
        for s in 0:5
            G.map(land + 2land .* seas[s] + land .* city .* .!seas[s])
            savefig("suds/fig/map$(g)_slr$(s).png")
        end

        city = G.crop(city, coastbox, box)
        for s in Sea.levels
            seas[s] == false && continue
            seas[s] = G.crop(seas[s], coastbox, box)
        end
        
    end

    facilities = Facility.rasters(box)
    roads = Road.rasters(box)
    roadlengths = Road.kilometers(poly)
    light = Light.raster(box)
    cuts = percentile.(Ref(light[city]), [25,50,75])
    light_q = map(l -> sum(l .> cuts) + 1, light)

    function make_df(lightcity, lightstr)

        S = length(Sea.levels)
        N = 1 + length(Facility.types) + length(Road.types)
        lightcol = Vector{String}(undef, N)
        varcol = Vector{String}(undef, N)
        totalcol = Vector{Int}(undef, N)
        slrcols = Matrix{Int}(undef, N, S)
        slrcolnames = string.("slr", (1:S) .- 1)
        
        function fill_row!(i, varstr, varcity, adj)
            lightcol[i] = lightstr
            varcol[i] = varstr
            totalcol[i] = round(Int, sum(varcity) * adj)
            for (j, s) in enumerate(Sea.levels)
                slrcols[i, j] = seas[s] == false ? 0 : 
                                round(Int, dot(varcity, seas[s]) * adj)
            end
            row += 1
        end
        row = 1

        fill_row!(row, "area", lightcity, area / sum(city))
        for type in Facility.types
            fill_row!(row, type, lightcity .* facilities[type], 1.)
        end
        for type in Road.types
            sum_road = sum(city .* roads[type])
            adj = sum_road > 0 ? roadlengths[type] / sum_road : 1.
            fill_row!(row, type, lightcity .* roads[type], adj)
        end
        
        return DataFrame(
            "light" => lightcol,
            "var"   => varcol,
            "total" => totalcol,
            [col => slrcols[:, i] for (i, col) in enumerate(slrcolnames)]...
        )

    end
     
    df = vcat( make_df(city, "all"),
               make_df(city .* (light_q .== 1), "q1"),
               make_df(city .* (light_q .== 2), "q2"),
               make_df(city .* (light_q .== 3), "q3"),
               make_df(city .* (light_q .== 4), "q4") )

    CSV.write("suds/tab/data$(g).csv", df)
    println("$(g). $(name)")

end

GS = eachindex(City.ghs)

elapsed_time = @elapsed for g in GS
    @time make_data(g) 
end
println("\nTotal: $elapsed_time seconds")

function read_data(g)
    df = CSV.read("suds/tab/data$(g).csv", DataFrame)
    df.g .= g 
    return df 
end
data = vcat(read_data.(GS)...)
data = rightjoin(City.data, data, on=:g)

CSV.write("suds.csv", data)
cd(@__DIR__)
using CairoMakie, CSV, DataFrames, StatsBase

# Data

data = CSV.read("suds.csv", DataFrame)
citycols = names(data)[1:7]
slrcols = names(data)[11:61]
meters = 0:0.1:5

data_coast = begin
    df = filter(row -> row.light == "all", data)
    df = filter(row -> row.var == "land", df)
    df = filter(row -> row.slr50 > 0, df)
    filter(row -> row.g ∈ df.g, data)
end

land = ["land"]
education = ["school"]
education_ = [education..., "kindergarten", "college", "university"]
health = ["hospital", "clinic"]
health_ = [health..., "doctors", "dentist", "pharmacy"]
transport = ["highway", "primary"]
transport_ = [transport..., "secondary", "tertiary"]

# Exposure

function exposure(data, vars; lights = ["all"], gdps = ["q1", "q2", "q3", "q4"])
    df = filter(row -> row.var ∈ vars, data)
    df = filter(row -> row.light ∈ lights, df)
    df = filter(row -> row.gdp ∈ gdps, df)
    gdf = groupby(df, citycols)
    cols = ["total", slrcols...] 
    return combine(gdf, cols .=> sum .=> cols)
end
function Σ(df; pop_wt = true)
    df.wt .= pop_wt ? df.pop ./ df.area : 1
    total = sum(df.total .* df.wt)
    percent(slrcol) = sum(df[!, slrcol] .* df.wt) / total * 100
    return percent.(slrcols)
end

world(data, vars) = exposure(data, vars) |> Σ
cities_H(data, vars) = exposure(data, vars; gdps = ["q3", "q4"]) |> Σ
cities_L(data, vars) = exposure(data, vars; gdps = ["q1", "q2"]) |> Σ
nbhds_H(data, vars) = exposure(data, vars; lights = ["q3", "q4"]) |> Σ
nbhds_L(data, vars) = exposure(data, vars; lights = ["q1", "q2"]) |> Σ

# Table

function tab(vars, col, slr, N)
    df = exposure(data, vars)[1:N,:]
    df[!, col] = df[!, slr] ./ df.total * 100
    return df[!, [:city, col]]
end
function tab(slr, n, N)
    df = tab(education, :E, slr, N)
    leftjoin!(df, tab(health, :H, slr, N), on=:city)
    leftjoin!(df, tab(transport, :T, slr, N), on=:city)
    df.I = (df.E + df.H + df.T) / 3
    select!(df, [:city, :I])
    sort!(df, :I, rev=true)
    df.I = string.(round.(df.I, digits=1))
    rename!(df, names(df) .* slr[4:end])
    return df[1:n, :]
end
function tab(n, N)
    ts = tab.(["slr10", "slr20", "slr30"], n, N)
    return hcat(ts...)
end

CSV.write("paper/tab.csv", tab(10, 30))

# Figure

function set(; ylims, yticks, fontsize=14)
    fig = Figure(size=(400,400), fonts=(; regular="CMU Serif"))
    ax = Axis(fig[1, 1], 
        xlabel="SLR (m)", ylabel="Exposure (%)", 
        xlabelsize=fontsize+1, ylabelsize=fontsize+1,
        xticklabelsize=fontsize, yticklabelsize=fontsize,
        xticks=0:5, yticks=yticks,
        limits=((-0.25,5.25), ylims)
    )
    return fig, ax, fontsize
end
function fig(data, region_H, region_L; kwargs...)
    fig, ax, fontsize = set(; kwargs...)
    ll = region_L(data, land)
    il = sum(region_L.(Ref(data), [education, health, transport])) / 3
    lh = region_H(data, land)
    ih = sum(region_H.(Ref(data), [education, health, transport])) / 3
    ll = lines!(ax, meters, ll; color=:red, linewidth=2, linestyle=:dash)
    il = lines!(ax, meters, il; color=:black, linewidth=2, linestyle=:dash)
    lh = lines!(ax, meters, lh; color=:red, linewidth=2)
    ih = lines!(ax, meters, ih; color=:black, linewidth=2)
    axislegend(ax, position=:lt, patchsize=(30,20), 
        titlegap=-1, groupgap=6, rowgap=-3,
        titlesize=fontsize, labelsize=fontsize,
        titlefont=:regular, titlehalign=:left,
        [[ih, lh], [il, ll]],
        [["Infrastructure", "Land"], ["Infrastructure", "Land"]],
        ["Higher-income", "Lower-income"];
    )
    hidespines!(ax, :t, :r); fig
end
args = (ylims=(-0.75,15.75), yticks=0:3:15)
args_coast = (ylims=(-2.5,52.5), yticks=0:10:50)

save("paper/figA.pdf", fig(data, cities_H, cities_L; args...))
save("paper/figB.pdf", fig(data_coast, cities_H, cities_L; args_coast...))
save("paper/figC.pdf", fig(data, nbhds_H, nbhds_L; args...))
save("paper/figD.pdf", fig(data_coast, nbhds_H, nbhds_L; args_coast...))

infra(data, s) = map(x -> world(data, x)[s], [education, health, transport]) |> mean
s = findfirst(meters .== 1.5)
infra(data, s) 
infra(data_coast, s)
s = findfirst(meters .== 5)
infra(data, s) 
infra(data_coast, s)
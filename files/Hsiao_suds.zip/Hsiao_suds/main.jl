cd(@__DIR__)
using CairoMakie, CSV, DataFrames, StatsBase

# Data

data = CSV.read("suds.csv", DataFrame)
citycols = names(data)[1:7]
slrcols = names(data)[11:61]
meters = 0:0.1:5

land = ["land"]
education = ["school"]
education_ = [education..., "kindergarten", "college", "university"]
health = ["hospital", "clinic"]
health_ = [health..., "doctors", "dentist", "pharmacy"]
transport = ["highway", "primary"]
transport_ = [transport..., "secondary", "tertiary"]

# Exposure

function exposure(vars; lights = ["all"], gdps = ["q1", "q2", "q3", "q4"])
    df = filter(row -> row.var ∈ vars, data)
    df = filter(row -> row.light ∈ lights, df)
    df = filter(row -> row.gdp ∈ gdps, df)
    gdf = groupby(df, citycols)
    cols = ["total", slrcols...] 
    return combine(gdf, cols .=> sum .=> cols)
end
function Σ(df; pop_wt = true)
    df.wt .= pop_wt ? df.pop ./ df.area : 1
    total = sum(df.total .* df.wt)
    percent(slrcol) = sum(df[!, slrcol] .* df.wt) / total * 100
    return percent.(slrcols)
end

world(vars) = exposure(vars) |> Σ
cities_H(vars) = exposure(vars; gdps = ["q3", "q4"]) |> Σ
cities_L(vars) = exposure(vars; gdps = ["q1", "q2"]) |> Σ
nbhds_H(vars) = exposure(vars; lights = ["q3", "q4"]) |> Σ
nbhds_L(vars) = exposure(vars; lights = ["q1", "q2"]) |> Σ

# Table

function tab(vars, col, slr, N)
    df = exposure(vars)[1:N,:]
    df[!, col] = df[!, slr] ./ df.total * 100
    return df[!, [:city, col]]
end
function tab(slr, n, N)
    df = tab(education, :E, slr, N)
    leftjoin!(df, tab(health, :H, slr, N), on=:city)
    leftjoin!(df, tab(transport, :T, slr, N), on=:city)
    df.I = (df.E + df.H + df.T) / 3
    select!(df, [:city, :I])
    sort!(df, :I, rev=true)
    df.I = string.(round.(df.I, digits=1))
    rename!(df, names(df) .* slr[4:end])
    return df[1:n, :]
end
function tab(n, N)
    ts = tab.(["slr10", "slr20", "slr30"], n, N)
    return hcat(ts...)
end

CSV.write("paper/tab.csv", tab(10, 30))

# Figure

function set(; fontsize=14)
    fig = Figure(size=(400,400), fonts=(; regular="CMU Serif"))
    ax = Axis(fig[1, 1], 
        xlabel="SLR (m)", ylabel="Exposure (%)", 
        xlabelsize=fontsize+1, ylabelsize=fontsize+1,
        xticklabelsize=fontsize, yticklabelsize=fontsize,
        xticks=0:5, yticks=0:5:15,
        limits=(-0.25,5.25,-0.75,15.75)
    )
    return fig, ax, fontsize
end
function fig(region_H, region_L)
    fig, ax, fontsize = set()
    ll, il = region_L(land), sum(region_L.([education, health, transport])) / 3
    lh, ih = region_H(land), sum(region_H.([education, health, transport])) / 3
    ll = lines!(ax, meters, ll; color=:red, linewidth=2, linestyle=:dash)
    il = lines!(ax, meters, il; color=:black, linewidth=2, linestyle=:dash)
    lh = lines!(ax, meters, lh; color=:red, linewidth=2)
    ih = lines!(ax, meters, ih; color=:black, linewidth=2)
    axislegend(ax, position=:lt, patchsize=(30,20), 
        titlegap=-1, groupgap=6, rowgap=-3,
        titlesize=fontsize, labelsize=fontsize,
        titlefont=:regular, titlehalign=:left,
        [[ih, lh], [il, ll]],
        [["Infrastructure", "Land"], ["Infrastructure", "Land"]],
        ["Higher-income", "Lower-income"];
    )
    hidespines!(ax, :t, :r); fig
end
function fig(region, education, health, transport)
    fig, ax, fontsize = set()
    l, e, h, t = region.([land, education, health, transport])
    l = lines!(ax, meters, l; color=:red, linewidth=2)
    e = lines!(ax, meters, e; color=:black, linewidth=2, linestyle=:dot)
    h = lines!(ax, meters, h; color=:black, linewidth=2, linestyle=:dash)
    t = lines!(ax, meters, t; color=:black, linewidth=2)
    axislegend(ax, position=:lt, patchsize=(30,20), 
        titlegap=-1, groupgap=6, rowgap=-3,
        titlesize=fontsize, labelsize=fontsize,
        titlefont=:regular, titlehalign=:left,
        [[e,h,t], [l]],
        [["Education", "Health", "Transport"], ["Land          "]],
        ["", ""];
    )
    hidespines!(ax, :t, :r); fig
end

save("paper/figA.pdf", fig(cities_H, cities_L))
save("paper/figB.pdf", fig(nbhds_H, nbhds_L))
save("paper/figC.pdf", fig(world, education, health, transport))
save("paper/figD.pdf", fig(world, education_, health_, transport_))
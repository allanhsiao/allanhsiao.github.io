# Sea Level Rise and Urban Inequality
# Allan Hsiao
# May 2024

statapath = "/Applications/Stata/StataSE.app/Contents/MacOS/stata-se"
stata(file) = run(`$(statapath) -b $(file)`)
cd(@__DIR__)

stata("code/data.do")
stata("code/estim.do")
include("code/cfs.jl")

temp = ["data/data.dta", "data/data.csv"]
logs = ["data.log", "estim.log"]
rm.([temp; logs])
#######################
#   Counterfactuals   #
#######################

using CSV, DataFrames, NLsolve, StatsBase

# data
df = CSV.read("data/data.csv", DataFrame)
X = Matrix(df[!,[:dist_coast, :dist_river]])
J = 0:1

# parameters
b = CSV.File("paper/estim_iv.csv", skipto=3, select=[1,2]) |> Dict
α = [b["lnp_$(j)"] for j in J]
β = b["f"]
γ = [b["dist_coast"], b["dist_river"]]
δ = begin 
    δ̂(j) = df[!, "lnpi_$(j)"] - α[j+1] * df.lnp - β * df.f - X * γ
    δ̂.(J)
end

# populations
N = begin 
    N̂(j) = round.(Int, df[1, "N_$(j)"])
    N̂.(J)
end

# model 
v̂(j, lnp, f) = α[j+1] * lnp + β * f + X * γ + δ[j+1]
function π̂(j, lnp, f)
    v = v̂(j, lnp, f)
    π̃ = exp.(v) ./ sum(skipmissing(exp.(v)))
    return coalesce.(π̃, 0.0)
end
n̂(j, lnp, f) = π̂(j, lnp, f) * N[j+1]

# sea level rise
below(m) = df.elev .<= m
f̂(m) = maximum(df.f) .* below(m) + df.f .* .!below(m)
MS = [0, 1, 3, 5]
fs = f̂.(MS)
println(round.(mean.(below.(MS)) * 100, digits=1))
println(maximum(df.f))

# equilibrium
demand(lnp, f) = mapreduce(j -> n̂(j, lnp, f), +, J)
supply = demand(df.lnp, df.f)
clear(lnp, f) = demand(lnp, f) - supply
function lnp̂(f; lnp₀ = df.lnp, f₀ = df.f)
    function f!(F, lnp)
        F .= clear(lnp, f)
        F[1] = lnp[1]
    end
    lnp̃ = lnp₀ - β / mean(α) * (f - f₀)
    return nlsolve(f!, lnp̃; autodiff = :forward).zero
end

# solve
lnps = lnp̂.(fs)
πs = map(j -> π̂.(j, lnps, fs), J)
mse(x) = mean(x.^2)
@assert all(mse.(clear.(lnps, fs)) .< 1e-12)

# flooding
F(f, π) = sum(f .* π)
Fs = map(j -> F.(fs, πs[j]), eachindex(J))
F̃s = map(j -> F.(fs, Ref(πs[j][1])), eachindex(J))

# prices
P(lnp, π) = sum(lnp .* π)
Ps = map(j -> P.(lnps, πs[j]), eachindex(J))
P̃s = map(j -> P.(lnps, Ref(πs[j][1])), eachindex(J))

# export
cfs = DataFrame(m = MS)
cfs.F0_sort = Fs[1]
cfs.F1_sort = Fs[2]
cfs.F01_sort = Fs[1] ./ Fs[2]
cfs.P01_sort = Ps[1] - Ps[2]
cfs.F0_nosort = F̃s[1]
cfs.F1_nosort = F̃s[2]
cfs.F01_nosort = F̃s[1] ./ F̃s[2]
cfs.P01_nosort = P̃s[1] - P̃s[2]
CSV.write("paper/table3.csv", cfs)